# -*- coding: utf-8 -*-
VERSION = 'VERSION'
