# -*- coding: utf-8 -*-

from application import app

# load views
import views
import views.index

if __name__ == '__main__':
    app.run()
