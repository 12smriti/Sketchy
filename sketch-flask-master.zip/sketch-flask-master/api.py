# -*- coding: utf-8 -*-

from application import app

# load apis
import apis

if __name__ == '__main__':
    app.run()
